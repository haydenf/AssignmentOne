Userstory
Enter main menu
enter the player names
select story
each user gets to chose a word to fill in the blank
after every blank has been filled, prints out entire story for user to read 
ability to exit app or continue onto another story


Psuedo

1. Open up show MadLibs as a title, press enter to start
2. Get user to enter name for each user playing and store this into an array
3. After user has entered names, get them to select a story using 1/2/3/4 keys 
story is based on a topic. 
4. story is selected then it will go through and fill all the blanks, will
put outenter a noun. clear the space then enter a verb and push all these
into a variable
5. after all blanks have been filled, grab the variable in and 
put them into the blanks of the story.
6. give user option to quit or continue on with story
